<?

// PHP-Matotest usage example
//
// http://php-matotest.sourceforge.net/
//
// PHP-Matotest is a foul-slang detector for Russian language.
// Based on Lingua::RU::Censure 0.050.01 - Perl extension for automatically
// detect deprecated russian slang, written by 
// Michael B. Babakov <M.Babakov@sochi.net.ru> and 
// Artur Penttinen <artur@niif.spb.su>.
//
// Ported to PHP by Scarab <scarab@initgroup.chat.ru>, 2002-2003.
//
// $Header: /cvsroot/php-matotest/matotest/example.php,v 1.1.1.1 2003/05/12 15:16:46 iscarab Exp $


require("TCensure.class.php");

$censor = new TCensure;
$test = fopen("test.log", "r");

while(!feof($test)) {
    $line = fgets($test, 2048);
    if (!$censor->CheckPhrase($line)) {
	echo("<b>".$line."</b><br>");
	echo($censor->GetRule());
	echo("<font color=red>".$censor->GetWord()."</font>");
	echo("<br><br>");
    }
    else { echo("<font color=green>".$line."</font>"); echo("<br>"); }
}
fclose($test);

?>
